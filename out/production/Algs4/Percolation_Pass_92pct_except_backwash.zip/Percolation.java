import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private final int myN;
    private final boolean[] open;
    private int openSiteCount;
    private final WeightedQuickUnionUF uf;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n)    {
        if (n <= 0)
            throw new IllegalArgumentException();

        myN = n;
        open = new boolean[myN * myN];
        openSiteCount = 0;

        for (int row = 1; row <= myN; row++)
            for (int col = 1; col <= myN; col++)
                open[rowCol(row, col)] = false;

        // The additional 2 nodes, one for virtual top node, one for virtual bottom node
        uf = new WeightedQuickUnionUF(myN * myN +2);

        // Top row all connected to the virtual top node
        for (int col = 1; col <= myN; col++)
            uf.union(rowCol(1, col), rowCol(myN, myN)+1);

        // Bottom row all connected to the virtual bottom node - It will create Backwash Problem
        for (int col = 1; col <= myN; col++)
            uf.union(rowCol(myN, col), rowCol(myN, myN)+2);
    }

    private int rowCol(int row, int col)    {
        return myN *(row-1)+(col-1);
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col)    {
        if (row < 1 || row > myN)
            throw new IllegalArgumentException();

        if (col < 1 || col > myN)
            throw new IllegalArgumentException();

        if (!isOpen(row, col)) {
            open[rowCol(row, col)] = true;
            openSiteCount++;

            if (row - 1 >= 1)
                if (isOpen(row - 1, col))
                    uf.union(rowCol(row, col), rowCol(row - 1, col));

            if (col - 1 >= 1)
                if (isOpen(row, col - 1))
                    uf.union(rowCol(row, col), rowCol(row, col - 1));

            if (row + 1 <= myN)
                if (isOpen(row + 1, col))
                    uf.union(rowCol(row, col), rowCol(row + 1, col));

            if (col + 1 <= myN)
                if (isOpen(row, col + 1))
                    uf.union(rowCol(row, col), rowCol(row, col + 1));
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col)    {
        if (row < 1 || row > myN)
            throw new IllegalArgumentException();

        if (col < 1 || col > myN)
            throw new IllegalArgumentException();

        return open[rowCol(row, col)];
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col)    {
        if (row < 1 || row > myN)
            throw new IllegalArgumentException();

        if (col < 1 || col > myN)
            throw new IllegalArgumentException();

        if (isOpen(row, col))
            return uf.find(rowCol(row, col)) == uf.find(rowCol(myN, myN)+1);
        else
            return false;
    }

    // returns the number of open sites
    public int numberOfOpenSites()    {
        return openSiteCount;
    }

    // does the system percolate?
    public boolean percolates()    {
        return uf.find(rowCol(myN, myN)+1) == uf.find(rowCol(myN, myN)+2);
    }

    // test client (optional)
    public static void main(String[] args)    {
        // empty main function
    }
}