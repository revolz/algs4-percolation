import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
// import edu.princeton.cs.algs4.QuickFindUF;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;


public class Percolation {
    private int N;
    private int[] id;
    private int openSiteCount;
    // private QuickFindUF uf;
    private WeightedQuickUnionUF uf;
    private boolean alreadyPercolated;
    private boolean changed;

    private int RowCol(int row, int col)    {
        return N*(row-1)+(col-1);
    }

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n)    {
        if (n <= 0)
            throw new IllegalArgumentException();

        N = n;
        id = new int[N*N];
        openSiteCount = 0;
        alreadyPercolated = false;
        changed = false;

        for (int row = 1; row <= N; row++)
            for (int col = 1; col <= N; col++)
                id[RowCol(row,col)] = 0;

        // The additional 2 nodes, one for virtual top node, one for virtual bottom node
        uf = new WeightedQuickUnionUF(N*N+2);

        // Top row all connected to the virtual top node
        for (int col = 1; col <= N; col++)
            uf.union(RowCol(1, col),RowCol(N,N)+1);

        // Bottom row all connected to the virtual bottom node - It will create Backwash Problem
        //for (int col = 1; col <= N; col++)
        //    uf.union(RowCol(N, col),RowCol(N,N)+2);
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col)    {
        if (row < 1 || row > N)
            throw new IllegalArgumentException();

        if (col < 1 || col > N)
            throw new IllegalArgumentException();

        if( !isOpen(row, col) ) {
            id[RowCol(row, col)] = 1;
            openSiteCount++;
            changed = true;

            if (row - 1 >= 1)
                if (isOpen(row - 1, col))
                    uf.union(RowCol(row, col), RowCol(row - 1, col));

            if (col - 1 >= 1)
                if (isOpen(row, col - 1))
                    uf.union(RowCol(row, col), RowCol(row, col - 1));

            if (row + 1 <= N) {
                if (isOpen(row + 1, col)) {
                    uf.union(RowCol(row, col), RowCol(row + 1, col));

                    // If it is the last row, connect it to the virtual bottom node
                    // To avoid backwash problem if it was done in the constructor
                    // if (row + 1 == N && isFull(row + 1, col))
                    //    uf.union(RowCol(N, N) + 2, RowCol(row + 1, col));
                }
            }

            if (col + 1 <= N)
                if (isOpen(row, col + 1))
                    uf.union(RowCol(row, col), RowCol(row, col + 1));
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col)    {
        if (row < 1 || row > N)
            throw new IllegalArgumentException();

        if (col < 1 || col > N)
            throw new IllegalArgumentException();

        return id[RowCol(row,col)] == 1;
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col)    {
        if (row < 1 || row > N)
            throw new IllegalArgumentException();

        if (col < 1 || col > N)
            throw new IllegalArgumentException();

        if( isOpen(row,col) )
            // return uf.connected(RowCol(row,col), N*N);
            return uf.connected(RowCol(row,col), RowCol(N,N)+1);
        else
            return false;
    }

    // returns the number of open sites
    public int numberOfOpenSites()    {
        return openSiteCount;
    }

    // does the system percolate?
    public boolean percolates()    {
        // return uf.connected(N*N, N*N+1);
        // return uf.connected( RowCol(N,N)+1, RowCol(N,N)+2);

        if( changed && !alreadyPercolated ) {
            for (int col = 1; col <= N; col++) {
               if( isOpen(N, col)) { // It helps to avoid error in corner cases N=1 and N=2
                   if (uf.connected(RowCol(N, N) + 1, RowCol(N, col))) {
                       alreadyPercolated = true;
                       changed = false;
                   }
               }
            }
        }

        return alreadyPercolated;
    }

    // test client (optional)
    public static void main(String[] args)    {
        StdOut.println("Hello World, Android Studio!");
        StdOut.println("Random Uniform Number = " + StdRandom.uniform());
    }
}